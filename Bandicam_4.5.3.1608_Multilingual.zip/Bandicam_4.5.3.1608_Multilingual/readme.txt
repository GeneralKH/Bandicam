1. Install Bandicam. Don't run it!
2. Register bandicam with keygen.
3. Copy loader to program folder and run as Admin. 

Run the application always from the loader.
=================
